"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.deactivate = exports.activate = void 0;
// The module 'vscode' contains the VS Code extensibility API
// Import the module and reference it with the alias vscode in your code below
const vscode = require("vscode");
const yaml = require("yaml");
const ajv_1 = require("ajv");
// This method is called when your extension is activated
// Your extension is activated the very first time the command is executed
function activate(context) {
    // Use the console to output diagnostic information (console.log) and errors (console.error)
    // This line of code will only be executed once when your extension is activated
    console.log('Congratulations, your extension "yaml-validator" is now active!');
    // The command has been defined in the package.json file
    // Now provide the implementation of the command with registerCommand
    // The commandId parameter must match the command field in package.json
    let disposable = vscode.commands.registerCommand('yaml-validator.validateYaml', () => {
        // The code you place here will be executed every time your command is executed
        // Display a message box to the user
        // 	vscode.window.showInformationMessage('Hello World from YAML Validator!');
        // });
        // context.subscriptions.push(disposable);
        const editor = vscode.window.activeTextEditor;
        if (editor) {
            const document = editor.document;
            const content = document.getText();
            // Load the JSON schema (adjust the schemaPath accordingly)
            // const schemaPath = path.join(__dirname, 'schema.json');;
            const schema = {
                "title": "Person",
                "type": "object",
                "properties": {
                    "firstName": {
                        "type": "string",
                        "description": "The person's first name."
                    },
                    "lastName": {
                        "type": "string",
                        "description": "The person's last name."
                    },
                    "age": {
                        "description": "Age in years which must be equal to or greater than zero.",
                        "type": "integer",
                        "minimum": 0
                    }
                }
            };
            // Parse YAML content
            try {
                const parsedYAML = yaml.parse(content);
                // Validate YAML against JSON schema
                const ajv = new ajv_1.default();
                const validate = ajv.compile(schema);
                const isValid = validate(parsedYAML);
                if (isValid) {
                    vscode.window.showInformationMessage('YAML is valid according to the schema.');
                }
                else {
                    const validationErrors = validate.errors || [];
                    vscode.window.showErrorMessage(`YAML validation failed:\n${JSON.stringify(validationErrors, null, 2)}`);
                }
            }
            catch (error) {
                vscode.window.showErrorMessage(`Error parsing YAML: ${error}`);
            }
        }
    });
    context.subscriptions.push(disposable);
}
exports.activate = activate;
// This method is called when your extension is deactivated
function deactivate() { }
exports.deactivate = deactivate;
//# sourceMappingURL=extension.js.map