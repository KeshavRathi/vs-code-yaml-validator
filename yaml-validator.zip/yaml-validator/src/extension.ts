// The module 'vscode' contains the VS Code extensibility API
// Import the module and reference it with the alias vscode in your code below
import * as vscode from 'vscode';
import * as yaml from 'yaml';
import Ajv, { ErrorObject } from 'ajv';
import * as path from 'path';


// This method is called when your extension is activated
// Your extension is activated the very first time the command is executed
export function activate(context: vscode.ExtensionContext) {

	// // Use the console to output diagnostic information (console.log) and errors (console.error)
	// // This line of code will only be executed once when your extension is activated
	// console.log('Congratulations, your extension "yaml-validator" is now active!');

	// // The command has been defined in the package.json file
	// // Now provide the implementation of the command with registerCommand
	// // The commandId parameter must match the command field in package.json
	// let disposable = vscode.commands.registerCommand('yaml-validator.validateYaml', () => {
	// 	// The code you place here will be executed every time your command is executed
	// 	// Display a message box to the user
	// // 	vscode.window.showInformationMessage('Hello World from YAML Validator!');
	// // });

	// // context.subscriptions.push(disposable);

	// const editor = vscode.window.activeTextEditor;

	//     if (editor) {
	//         const document = editor.document;
	//         const content = document.getText();

	//         // Load the JSON schema (adjust the schemaPath accordingly)
	//         // const schemaPath = path.join(__dirname, 'schema.json');;
	//         const schema = {
	// 			"title": "Person",
	// 			"type": "object",
	// 			"properties": {
	// 			  "firstName": {
	// 				"type": "string",
	// 				"description": "The person's first name."
	// 			  },
	// 			  "lastName": {
	// 				"type": "string",
	// 				"description": "The person's last name."
	// 			  },
	// 			  "age": {
	// 				"description": "Age in years which must be equal to or greater than zero.",
	// 				"type": "integer",
	// 				"minimum": 0
	// 			  }
	// 			}
	// 		  };

	//         // Parse YAML content
	//         try {
	//             const parsedYAML = yaml.parse(content);

	//             // Validate YAML against JSON schema
	//             const ajv = new Ajv();
	//             const validate = ajv.compile(schema);
	//             const isValid = validate(parsedYAML);

	//             if (isValid) {
	//                 vscode.window.showInformationMessage('YAML is valid according to the schema.');
	//             } else {
	//                 const validationErrors = validate.errors || [];
	//                 vscode.window.showErrorMessage(`YAML validation failed:\n${JSON.stringify(validationErrors, null, 2)}`);
	//             }
	//         } catch (error) {
	//             vscode.window.showErrorMessage(`Error parsing YAML: ${error}`);
	//         }
	//     }
	// });

	// context.subscriptions.push(disposable);

	// Trigger validation on text document changes
	context.subscriptions.push(vscode.workspace.onDidChangeTextDocument(event => {
		validateYAML(event.document);
	}));

	// Trigger validation on text document save
	context.subscriptions.push(vscode.workspace.onDidSaveTextDocument(document => {
		validateYAML(document);
	}));
}

// function validateYAML(document: vscode.TextDocument) {
//     const content = document.getText();

//     const schema = {
// 		"title": "Person",
// 		"type": "object",
// 		"properties": {
// 		  "firstName": {
// 			"type": "string",
// 			"description": "The person's first name."
// 		  },
// 		  "lastName": {
// 			"type": "string",
// 			"description": "The person's last name."
// 		  },
// 		  "age": {
// 			"description": "Age in years which must be equal to or greater than zero.",
// 			"type": "integer",
// 			"minimum": 0
// 		  }
// 		}
// 	  };

//     try {
//         const parsedYAML = yaml.parse(content);

//         // Validate YAML against JSON schema
//         const ajv = new Ajv();
//         const validate = ajv.compile(schema);
//         const isValid = validate(parsedYAML);

//         if (!isValid) {
//             const validationErrors = validate.errors || [];
//             vscode.window.showErrorMessage(`YAML validation failed:\n${JSON.stringify(validationErrors, null, 2)}`);
//         }
//     } catch (error) {
//         vscode.window.showErrorMessage(`Error parsing YAML: ${error}`);
//     }
// }

export function validateYAML(document: vscode.TextDocument) {
	const content = document.getText();

	// Load and parse the JSON schema (replace with actual schema)
	const schema = {
		"title": "Person",
		"type": "object",
		"properties": {
			"firstName": {
				"type": "string",
				"description": "The person's first name."
			},
			"lastName": {
				"type": "string",
				"description": "The person's last name."
			},
			"age": {
				"description": "Age in years which must be equal to or greater than zero.",
				"type": "integer",
				"minimum": 0
			}
		}
	};

	try {
		const parsedYAML = yaml.parse(content);

		// Validate YAML against JSON schema
		const ajv = new Ajv();
		const validate = ajv.compile(schema);
		const isValid = validate(parsedYAML);

		// Clear existing decorations
		const decorationType = vscode.window.createTextEditorDecorationType({
			backgroundColor: 'rgba(255, 0, 0, 0.2)',
			isWholeLine: true
		});

		// Get the active text editor
		const editor = vscode.window.activeTextEditor;

		if (!editor) {
			return;
		}

		editor.setDecorations(decorationType, []);

		if (!isValid && validate.errors) {
            // Create decorations for each error
            // const errorDecorations: vscode.DecorationOptions[] = validate.errors.map((error: ErrorObject) => {
            //     const instancePath = error.instancePath.replace(/^\//, ''); // Remove leading slash
            //     const lineNumber = document.positionAt(Number(instancePath)).line;
            //     const range = new vscode.Range(lineNumber, 0, lineNumber, 0); // Whole line
            //     return {
            //         range,
            //         hoverMessage: new vscode.MarkdownString(error.message || '')
            //     };
            // });
			console.log(validate.errors)
			const errorDecorations: vscode.DecorationOptions[] = validate.errors.map((error: ErrorObject) => {
                const instancePathSegments = error.instancePath.split('/').filter(segment => segment !== '');
                const lineNumber: any = instancePathSegments[instancePathSegments.length - 1];
                const range = new vscode.Range(lineNumber - 1, 0, lineNumber - 1, 0); // Convert to zero-based index
                return {
                    range,
                    hoverMessage: new vscode.MarkdownString(error.message || '')
                };
            });

            // Apply decorations to the editor
            editor.setDecorations(decorationType, errorDecorations);
        }
	} catch (error) {
		vscode.window.showErrorMessage(`Error parsing YAML: ${error}`);
	}
}

// This method is called when your extension is deactivated
export function deactivate() { }
